#%%
import random
import numpy as np
import torch
from torch import nn






class DescEncoder(nn.Module):
    """FFN to project manual descriptors into latent tokens."""
    def __init__(self, input_dim, token_dim=32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 64),
            nn.ReLU(),
            nn.Linear(64, token_dim),
            nn.ReLU()
        )

    def forward(self, x):
        return self.net(x)  # (batch, token_dim)

class EmbEncoder(nn.Module):
    """FFN to project semantic embedding into latent tokens."""
    def __init__(self, input_dim, token_dim=32):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(input_dim, 128),
            nn.ReLU(),
            nn.Linear(128, token_dim),
            nn.ReLU()
        )

    def forward(self, x):
        return self.net(x)  # (batch, token_dim)


class ICTF(nn.Module):
    def __init__(self, desc_dim, emb_dim, token_dim=32, num_heads=4,
                 num_layers=2, ff_hidden=None, num_classes=2, dropout=0.1):
        super().__init__()
        # Feature encoders (as before)
        self.desc_enc = DescEncoder(desc_dim, token_dim)
        self.emb_enc  = EmbEncoder(emb_dim, token_dim)

        ff_hidden = ff_hidden or token_dim

        # Learnable [CLS] token
        self.cls_token = nn.Parameter(torch.randn(1, 1, token_dim))

        # Transformer encoder layers
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=token_dim,
            nhead=num_heads,
            dim_feedforward=token_dim * 4,
            dropout=dropout,
            batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)

        # Classification head
        self.head = nn.Sequential(
            nn.Linear(token_dim, ff_hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(ff_hidden, num_classes)
        )

    def forward(self, desc, emb):
        desc_tok = self.desc_enc(desc)  # (batch, token_dim)
        emb_tok  = self.emb_enc(emb)    # (batch, token_dim)

        bsz = desc_tok.size(0)
        cls  = self.cls_token.expand(bsz, -1, -1)      # (batch,1,token_dim)
        stack = torch.stack([desc_tok, emb_tok], dim=1) # (batch,2,token_dim)
        tokens = torch.cat([cls, stack], dim=1)         # (batch,3,token_dim)

        enc_out = self.transformer(tokens)              # (batch,3,token_dim)
        cls_out = enc_out[:, 0, :]                      # (batch,token_dim)

        return self.head(cls_out)                       # (batch,num_classes)






