import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

# ─── 1. Specialized Encoders ───────────────────────────────────────────────
class GeneEncoder(nn.Module):
    def __init__(self, in_dim, emb_dim=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, 128),
            nn.ReLU(),
            nn.Linear(128, emb_dim)
        )
    def forward(self, x): return self.net(x)

class PrimerEncoder(nn.Module):
    def __init__(self, in_dim, emb_dim=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, 128),
            nn.ReLU(),
            nn.Linear(128, emb_dim)
        )
    def forward(self, x): return self.net(x)

class SuperSeqEncoder(nn.Module):
    def __init__(self, in_dim, emb_dim=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, 128),
            nn.ReLU(),
            nn.Linear(128, emb_dim)
        )
    def forward(self, x): return self.net(x)

class gRNAEncoder(nn.Module):
    def __init__(self, in_dim, emb_dim=64):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, 128),
            nn.ReLU(),
            nn.Linear(128, emb_dim)
        )
    def forward(self, x): return self.net(x)


# ─── 2. Causal Transformer Layer ────────────────────────────────────────────
class CausalTransformerLayer(nn.Module):
    def __init__(self, d_model, nhead):
        super().__init__()
        self.self_attn = nn.MultiheadAttention(d_model, nhead, batch_first=True)
        self.raw_A     = nn.Parameter(torch.zeros(d_model, d_model))
        self.ff        = nn.Sequential(
            nn.Linear(d_model, d_model * 4),
            nn.ReLU(),
            nn.Linear(d_model * 4, d_model),
        )
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)

    def forward(self, x):
        # Attention without explicit mask (all tokens attend)
        attn_out, _ = self.self_attn(x, x, x)
        x2 = self.norm1(x + attn_out)
        out = self.norm2(x2 + self.ff(x2))
        # DAG acyclicity penalty
        seq_len = x.size(1)
        dag_pen = torch.trace(torch.matrix_exp(self.raw_A * self.raw_A)) - seq_len
        return out, dag_pen


# ─── 3. Full Causal Attention Model ─────────────────────────────────────────
class CausalAttentionModel(nn.Module):
    def __init__(self, emb_dims, param_dim, cls_dim=64, nhead=4):
        super().__init__()
        self.gene_encoder      = GeneEncoder(emb_dims[0], 64)
        self.primer_encoder    = PrimerEncoder(emb_dims[1], 64)
        self.super_seq_encoder = SuperSeqEncoder(emb_dims[2], 64)
        self.grna_encoder      = gRNAEncoder(emb_dims[3], 64)

        self.param_proj = nn.Sequential(
            nn.Linear(param_dim, 128),
            nn.ReLU(),
            nn.Linear(128, cls_dim)
        )

        self.cls_token = nn.Parameter(torch.randn(1, 1, cls_dim))
        self.trans_layer = CausalTransformerLayer(d_model=cls_dim, nhead=nhead)
        self.classifier = nn.Sequential(
            nn.Linear(cls_dim, cls_dim // 2),
            nn.ReLU(),
            nn.Linear(cls_dim // 2, 1)
        )

    def forward(self, gene, primer, super_seq, grna, params):
        B = gene.size(0)
        cls_dim = self.cls_token.size(-1)

        encs = [
            self.gene_encoder(gene),
            self.primer_encoder(primer),
            self.super_seq_encoder(super_seq),
            self.grna_encoder(grna)
        ]

        param_emb = self.param_proj(params)  # (B, cls_dim)

        tokens = torch.stack(encs + [param_emb], dim=1)  # (B,5,cls_dim)
        cls_tok = self.cls_token.expand(B, 1, cls_dim)   # (B,1,cls_dim)
        seq = torch.cat([tokens, cls_tok], dim=1)        # (B,6,cls_dim)

        tr_out, dag_pen = self.trans_layer(seq)

        cls_out = tr_out[:, -1, :]
        logits = self.classifier(cls_out).squeeze(-1)

        return logits, dag_pen


# ─── 4. Example Usage ───────────────────────────────────────────────────────
if __name__ == "__main__":
    model = CausalAttentionModel(
        emb_dims=[512, 512, 512, 512],
        param_dim=10,
        cls_dim=64,
        nhead=4
    )
    gene, primer, super_seq, grna = [torch.randn(8, 512) for _ in range(4)]
    params = torch.randn(8, 10)

    logits, dag_pen = model(gene, primer, super_seq, grna, params)
    print("Logits:", logits.shape, " DAG penalty:", dag_pen.item())

